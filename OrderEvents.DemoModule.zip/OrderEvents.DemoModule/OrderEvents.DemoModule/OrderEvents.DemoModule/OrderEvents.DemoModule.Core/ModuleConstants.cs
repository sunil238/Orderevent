using System.Collections.Generic;
using VirtoCommerce.Platform.Core.Settings;

namespace OrderEvents.DemoModule.Core
{
    public static class ModuleConstants
    {
        public static class Security
        {
            public static class Permissions
            {
                public const string Access = "orderEventsDemoModule:access";
                public const string Create = "orderEventsDemoModule:create";
                public const string Read = "orderEventsDemoModule:read";
                public const string Update = "orderEventsDemoModule:update";
                public const string Delete = "orderEventsDemoModule:delete";

                public static string[] AllPermissions { get; } = { Read, Create, Access, Update, Delete };
            }
        }

        public static class Settings
        {
            public static class General
            {
                public static SettingDescriptor OrderEventsDemoModuleEnabled { get; } = new SettingDescriptor
                {
                    Name = "OrderEventsDemoModule.OrderEventsDemoModuleEnabled",
                    GroupName = "OrderEventsDemoModule|General",
                    ValueType = SettingValueType.Boolean,
                    DefaultValue = false
                };

                public static SettingDescriptor OrderEventsDemoModulePassword { get; } = new SettingDescriptor
                {
                    Name = "OrderEventsDemoModule.OrderEventsDemoModulePassword",
                    GroupName = "OrderEventsDemoModule|Advanced",
                    ValueType = SettingValueType.SecureString,
                    DefaultValue = "qwerty"
                };

                public static IEnumerable<SettingDescriptor> AllSettings
                {
                    get
                    {
                        yield return OrderEventsDemoModuleEnabled;
                        yield return OrderEventsDemoModulePassword;
                    }
                }
            }

            public static IEnumerable<SettingDescriptor> AllSettings
            {
                get
                {
                    return General.AllSettings;
                }
            }
        }
    }
}
