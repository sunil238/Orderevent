using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using OrderEvents.DemoModule.Core;
using VirtoCommerce.OrdersModule.Core.Model;

namespace OrderEvents.DemoModule.Web.Controllers.Api
{
    [Route("api/OrderEventsDemoModule")]
    public class OrderEventsDemoModuleController : Controller
    {
        // GET: api/OrderEventsDemoModule
        /// <summary>
        /// Get message
        /// </summary>
        /// <remarks>Return "Hello world!" message</remarks>
        [HttpGet]
        [Route("")]
        [Authorize(ModuleConstants.Security.Permissions.Read)]
        public ActionResult<string> Get()
        {
            return Ok(new { result = "Hello world!" });
        }
       
    }
}
