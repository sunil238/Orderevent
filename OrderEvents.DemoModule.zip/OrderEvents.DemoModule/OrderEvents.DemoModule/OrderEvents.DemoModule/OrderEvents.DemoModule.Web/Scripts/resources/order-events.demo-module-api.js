angular.module('orderEvents.demoModule')
    .factory('orderEvents.demoModule.webApi', ['$resource', function ($resource) {
        return $resource('api/OrderEventsDemoModule');
}]);
