﻿using System;
using System.Collections.Generic;
using System.Text;
using VirtoCommerce.Platform.Core.Events;
using VirtoCommerce.OrdersModule.Core.Model;
using VirtoCommerce.OrdersModule.Core.Events;
using System.Threading.Tasks;
using OrderEvents.DemoModule.Core.Events;

namespace OrderEvents.DemoModule.Data.Handlers
{
    public class OrderChangedEventHandler : IEventHandler<OrderChangedEvent>
    {
        private readonly IEventPublisher _eventPublisher;
        public OrderChangedEventHandler(IEventPublisher eventPublisher)
        {
            _eventPublisher = eventPublisher;
        }

        public async Task Handle(OrderChangedEvent message)
        {
            foreach(var order in message.ChangedEntries)
            {
                if (order.OldEntry.Status != order.NewEntry.Status)
                {
                    if (order.OldEntry.Status == "New" && order.NewEntry.Status == "Processing")
                    {
                        await _eventPublisher.Publish<OrderProcessEvent>(new OrderProcessEvent { Order = order.NewEntry });

                    }
                    else if (order.OldEntry.Status == "Processing" && order.NewEntry.Status == "Completed")
                    {
                        await _eventPublisher.Publish<OrderCompletedEvent>(new OrderCompletedEvent { Order = order.NewEntry });
                        
                    }
                    else
                    {
                        throw new InvalidOperationException();
                    }
                }
            }

        }
    }
}
